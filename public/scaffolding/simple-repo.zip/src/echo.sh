if [ $# -eq 1 ]
then
    echo $1
    exit 0
else
    echo no input error
    exit 1
fi