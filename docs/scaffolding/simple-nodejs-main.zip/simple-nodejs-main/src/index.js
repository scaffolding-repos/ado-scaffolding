const util = require('./util')

const result = util.add(1, 2)

console.log(result);