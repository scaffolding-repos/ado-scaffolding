# Overview

This is a sample project to demonstrate how the extension creates sample code, repo, branches, pipelines and variable groups.

The following list is the scope of this scaffolding:

1. Sample code
2. DevOps repo and branches
3. DevOps pipelines and variable groups
